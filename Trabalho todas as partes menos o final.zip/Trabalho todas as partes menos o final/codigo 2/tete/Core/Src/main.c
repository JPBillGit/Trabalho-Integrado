/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdlib.h>
#include <stdio.h>
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ST7789\st7789.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

/* USER CODE BEGIN PV */
uint8_t senha_gerada[4];
char senhaString[5];
char tentativaProfessor[5] = "____";
int digito_atual = 0;
int estado = 0;
int limiteAlunos = 0;
int alunosPresentes = 0;
int alunosFora = 0;
int totalSaidasRealizadas = 0;
int senhaNumerica[4];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */
void Random_Init(void) {
    srand(HAL_GetTick());
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void gerarSenhaSistema() {
    for(int i = 0; i < 4; i++) {
senhaNumerica[i] = (rand() % 4) + 1;
senhaString[i] = senhaNumerica[i] + '0';
    }
    senhaString[4] = '\0';
}
void AtualizarTelaSenha(void) {
	 ST7789_Fill_Color(BLACK);
	 ST7789_WriteString(10, 20, "INSIRA A SENHA", Font_11x18, WHITE, BLACK);

	  char exibicao[9];
	    exibicao[0] = tentativaProfessor[0]; exibicao[1] = ' ';
	    exibicao[2] = tentativaProfessor[1]; exibicao[3] = ' ';
	    exibicao[4] = tentativaProfessor[2]; exibicao[5] = ' ';
	    exibicao[6] = tentativaProfessor[3]; exibicao[7] = ' ';
	    exibicao[8] = '\0';

	    ST7789_WriteString(40, 100, exibicao, Font_16x26, YELLOW, BLACK);
}
int Random_Range(int min, int max) {
    return (rand() % (max - min + 1)) + min;
}

void GerarSenha(void) {
    for (int i = 0; i < 4; i++) {
        senha_gerada[i] = Random_Range(1, 4);
    }
}
void DesenharInterfaceSenha(void) {
    ST7789_Fill_Color(BLACK);
    ST7789_WriteString(10, 20, "INSIRA A SENHA AQUI", Font_11x18, WHITE, BLACK);

    ST7789_WriteString(40, 100, "_  _  _  _", Font_16x26, WHITE, BLACK);
}

int BotaoConfirmarTurma(void) {
    return (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_11) == GPIO_PIN_RESET &&
            HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_12) == GPIO_PIN_RESET);
}

void AtualizarTelaConfigTurma(void) {
    ST7789_Fill_Color(BLACK);
    ST7789_WriteString(10, 10,  "CONFIG DA TURMA",  Font_11x18, CYAN,  BLACK);
    ST7789_WriteString(10, 45,  "PA9 : -1",         Font_11x18, WHITE, BLACK);
    ST7789_WriteString(10, 68,  "PA10: -5",         Font_11x18, WHITE, BLACK);
    ST7789_WriteString(10, 91,  "PA11: +1",         Font_11x18, WHITE, BLACK);
    ST7789_WriteString(10, 114, "PA12: +5",         Font_11x18, WHITE, BLACK);
    ST7789_WriteString(10, 137, "PA11+PA12: OK",    Font_11x18, GREEN, BLACK);

    char buf[20];
    sprintf(buf, "Limite: %d  ", limiteAlunos);
    ST7789_WriteString(30, 170, buf, Font_16x26, YELLOW, BLACK);
}

void ProcessarConfigTurma(int botao) {

    if (BotaoConfirmarTurma()) {
        while (BotaoConfirmarTurma());
        HAL_Delay(50);

        if (limiteAlunos == 0) {
            ST7789_Fill_Color(RED);
            ST7789_WriteString(10, 100, "Min: 1 aluno!", Font_11x18, WHITE, RED);
            HAL_Delay(1000);
            AtualizarTelaConfigTurma();
            return;
        }
        ST7789_Fill_Color(BLACK);
                ST7789_WriteString(10, 20,  "CONFIRMAR TURMA?",   Font_11x18, CYAN,  BLACK);
                ST7789_WriteString(10, 60,  "Total de alunos:",   Font_11x18, WHITE, BLACK);
                char buf[10];
                sprintf(buf, "%d", limiteAlunos);
                ST7789_WriteString(90, 100, buf, Font_16x26, YELLOW, BLACK);
                ST7789_WriteString(10, 155, "PA11+PA12: Confirmar", Font_7x10, GREEN, BLACK);
                ST7789_WriteString(10, 170, "Outro btn : Voltar",   Font_7x10, RED,   BLACK);

                while (1) {
                    if (BotaoConfirmarTurma()) {
                        while (BotaoConfirmarTurma());
                        HAL_Delay(50);
                        ST7789_Fill_Color(GREEN);
                        ST7789_WriteString(10, 80,  "CONFIRMADO!", Font_11x18, BLACK, GREEN);
                        sprintf(buf, "%d alunos", limiteAlunos);
                        ST7789_WriteString(20, 115, buf, Font_16x26, BLACK, GREEN);
                        HAL_Delay(2000);
                        estado = 2;
                        ST7789_Fill_Color(BLACK);
                        return;
                    }

                    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_9)  == GPIO_PIN_RESET ||
                        HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_10) == GPIO_PIN_RESET ||
                        HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_11) == GPIO_PIN_RESET ||
                        HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_12) == GPIO_PIN_RESET) {
                        while (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_9)  == GPIO_PIN_RESET ||
                               HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_10) == GPIO_PIN_RESET ||
                               HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_11) == GPIO_PIN_RESET ||
                               HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_12) == GPIO_PIN_RESET);
                        HAL_Delay(50);
                        AtualizarTelaConfigTurma();
                        return;
                    }
                }
            }
    if (botao == 1) {
           if (limiteAlunos > 0) limiteAlunos--;
           AtualizarTelaConfigTurma();
       } else if (botao == 2) {
           if (limiteAlunos >= 5) limiteAlunos -= 5;
           else limiteAlunos = 0;
           AtualizarTelaConfigTurma();
       } else if (botao == 3) {
           limiteAlunos++;
           AtualizarTelaConfigTurma();
       } else if (botao == 4) {
           limiteAlunos += 5;
           AtualizarTelaConfigTurma();
       }
   }
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */
  ST7789_Init();
  srand(HAL_GetTick());
  GerarSenha();
  DesenharInterfaceSenha();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	   if (estado == 1 && BotaoConfirmarTurma()) {
		ProcessarConfigTurma(0);
	    continue;
}
	  int botao_apertado = 0;

	      if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_9) == GPIO_PIN_RESET)       botao_apertado = 1;
	      else if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_10) == GPIO_PIN_RESET) botao_apertado = 2;
	      else if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_11) == GPIO_PIN_RESET) botao_apertado = 3;
	      else if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_12) == GPIO_PIN_RESET) botao_apertado = 4;

	      if (botao_apertado > 0) {

	          while (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_9)  != GPIO_PIN_RESET &&
	                 HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_10) != GPIO_PIN_RESET &&
	                 HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_11) != GPIO_PIN_RESET &&
	                 HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_12) != GPIO_PIN_RESET);

	          HAL_Delay(50);

	          if (estado == 0) {
	                     if (digito_atual < 4) {
	                         tentativaProfessor[digito_atual] = botao_apertado + '0';
	                         digito_atual++;
	                         AtualizarTelaSenha();
	                         HAL_Delay(300);
	                     }
	                     if (digito_atual == 4) {
	                         HAL_Delay(500);
	                         int acertos = 0;
	                         for (int i = 0; i < 4; i++) {
	                             if ((tentativaProfessor[i] - '0') == senha_gerada[i]) acertos++;
	                         }
	                         if (acertos == 4) {
	                             ST7789_Fill_Color(GREEN);
	                             ST7789_WriteString(30, 100, "OK!", Font_16x26, BLACK, GREEN);
	                             HAL_Delay(1500);
	                             estado = 1;
	                             limiteAlunos = 0;
	                             AtualizarTelaConfigTurma();
	                         } else {
	                             ST7789_Fill_Color(RED);
	                             ST7789_WriteString(30, 100, "ERRO!", Font_16x26, WHITE, RED);
	                             HAL_Delay(1500);
	                             digito_atual = 0;
	                             for (int i = 0; i < 4; i++) tentativaProfessor[i] = '_';
	                             GerarSenha();
	                             AtualizarTelaSenha();
	                         }
	                     }

	                 } else if (estado == 1) {
	                     ProcessarConfigTurma(botao_apertado);
	                 }
	             }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_HIGH;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(ST7789_CS_GPIO_Port, ST7789_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, ST7789_DC_Pin|ST7789_RST_Pin|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_6, GPIO_PIN_RESET);

  /*Configure GPIO pin : ST7789_CS_Pin */
  GPIO_InitStruct.Pin = ST7789_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(ST7789_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : ST7789_DC_Pin ST7789_RST_Pin PB3 PB4
                           PB5 PB6 */
  GPIO_InitStruct.Pin = ST7789_DC_Pin|ST7789_RST_Pin|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PA9 PA10 PA11 PA12 */
  GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
